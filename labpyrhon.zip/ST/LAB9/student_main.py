import re

def task1(input_string):
    lowercase_digits_pattern = r'^[a-z0-9]+$'
    return bool(re.match(lowercase_digits_pattern, input_string))

def task2(input_string):
    return bool(re.search(r'[A-Z]', input_string))

def task3(input_string):
    ipv4_pattern = r'^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$'
    return bool(re.match(ipv4_pattern, input_string))

def task4(input_string):
    time_pattern = r'^([01]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$'
    return bool(re.match(time_pattern, input_string))

def task5(input_string):
    postal_code_pattern = r'^\d{5}(-\d{4})?$'
    return bool(re.match(postal_code_pattern, input_string))

def task6(input_string):
    username_pattern = r'^[a-z0-9_-]{6,12}$'
    return bool(re.match(username_pattern, input_string))

def task7(input_string):
    credit_card_pattern = r'^[4-6]\d{3}-?\d{4}-?\d{4}-?\d{4}$'
    return bool(re.match(credit_card_pattern, input_string))

def task8(input_string):
    ssn_pattern = r'^\d{3}-\d{2}-\d{4}$'
    return bool(re.match(ssn_pattern, input_string))

def task9(input_string):
    password_pattern = r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@#$%])[A-Za-z\d@#$%]{8,}$'
    return bool(re.match(password_pattern, input_string))

def task10(input_string):
    ipv6_pattern = r'^([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$'
    return bool(re.match(ipv6_pattern, input_string))

