Лабораторна робота №9: Регулярні вирази
Мета
Метою цієї лабораторної роботи є вивчення та застосування регулярних виразів у Python для перевірки та обробки текстових даних.
Завдання
Використовуючи регулярні вирази, реалізуйте наступні функції для перевірки різних текстових форматів.
Функції

 1. Перевірка рядка на наявність тільки малих літер та цифр


import re

def task1(input_string):
    lowercase_digits_pattern = r'^[a-z0-9]+$'
    return bool(re.match(lowercase_digits_pattern, input_string))

 Приклад використання
print(task1("abc123"))  # True
print(task1("ABC123"))  # False


2. Перевірка наявності великої літери у рядку
def task2(input_string):
    return bool(re.search(r'[A-Z]', input_string))

 Приклад використання
print(task2("HelloWorld"))  # True
print(task2("helloworld"))  # False


 3. Перевірка формату IPv4 адреси
def task3(input_string):
    ipv4_pattern = r'^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$'
    return bool(re.match(ipv4_pattern, input_string))

 Приклад використання
print(task3("192.168.1.1"))  # True
print(task3("999.999.999.999"))  # False


 4. Перевірка формату часу HH:MM:SS
def task4(input_string):
    time_pattern = r'^([01]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$'
    return bool(re.match(time_pattern, input_string))

 Приклад використання
print(task4("12:34:56"))  # True
print(task4("25:00:00"))  # False

 5. Перевірка формату поштового індексу США
def task5(input_string):
    postal_code_pattern = r'^\d{5}(-\d{4})?$'
    return bool(re.match(postal_code_pattern, input_string))

 Приклад використання
print(task5("12345"))  # True
print(task5("12345-6789"))  # True
print(task5("123456"))  # False


6. Перевірка формату імені користувача
def task6(input_string):
    username_pattern = r'^[a-z0-9_-]{6,12}$'
    return bool(re.match(username_pattern, input_string))

 Приклад використання
print(task6("username_1"))  # True
print(task6("user"))  # False


7. Перевірка формату кредитної картки
def task7(input_string):
    credit_card_pattern = r'^[4-6]\d{3}-?\d{4}-?\d{4}-?\d{4}$'
    return bool(re.match(credit_card_pattern, input_string))

 Приклад використання
print(task7("4111-1111-1111-1111"))  # True
print(task7("5111-1111-1111-1111"))  # True
print(task7("6111-1111-1111-1111"))  # True
print(task7("7111-1111-1111-1111"))  # False


8. Перевірка формату номера соціального страхування США
def task8(input_string):
    ssn_pattern = r'^\d{3}-\d{2}-\d{4}$'
    return bool(re.match(ssn_pattern, input_string))

Приклад використання
print(task8("123-45-6789"))  # True
print(task8("123-456-789"))  # False


9. Перевірка формату пароля
def task9(input_string):
    password_pattern = r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@#$%])[A-Za-z\d@#$%]{8,}$'
    return bool(re.match(password_pattern, input_string))

 Приклад використання
print(task9("Password1@"))  # True
print(task9("password"))  # False


10. Перевірка формату IPv6 адреси
def task10(input_string):
    ipv6_pattern = r'^([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$'
    return bool(re.match(ipv6_pattern, input_string))

Приклад використання
print(task10("2001:0db8:85a3:0000:0000:8a2e:0370:7334"))  # True
print(task10("2001:db8:85a3:0:0:8a2e:370:7334"))  # True
print(task10("2001::85a3::8a2e:370:7334"))  # False


Висновок
Ця лабораторна робота показує, як можна використовувати регулярні вирази для перевірки та обробки різних форматів текстових даних у Python. Регулярні вирази є потужним інструментом для ефективної роботи з текстом, що дозволяє швидко та точно виконувати валідацію вхідних даних.

Інструкції до запуску
1. Встановіть Python 3.12.4
2. Створіть файл `student_main.py` та вставте туди код функцій.
3. Запустіть файл, виконавши команду:
    python student_main.py
    
Переконайтеся, що у вас встановлені всі необхідні бібліотеки (в даному випадку використовується стандартна бібліотека Python).