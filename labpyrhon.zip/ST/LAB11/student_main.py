import collections
import math

# Task 1
def task1(nums):
    return sum(x ** 2 for x in nums)

# Task 2
def task2(nums):
    avg = sum(nums) / len(nums)
    return sum(x for x in nums if x >= avg)

# Task 3
def task3(nums):
    freq = collections.Counter(nums)
    return sorted(nums, key=lambda x: (-freq[x], x))

# Task 4
def task4(nums):
    n = len(nums) + 1
    total_sum = n * (n + 1) // 2
    return total_sum - sum(nums)

# Task 5
def task5(nums):
    num_set = set(nums)
    max_length = 0

    for num in num_set:
        if num - 1 not in num_set:
            current_num = num
            current_length = 1

            while current_num + 1 in num_set:
                current_num += 1
                current_length += 1

            max_length = max(max_length, current_length)

    return max_length

# Task 6
def task6(nums, k):
    n = len(nums)
    k %= n
    return nums[-k:] + nums[:-k]

# Task 7
def task7(nums):
    prefix_products = []
    suffix_products = []
    n = len(nums)
    result = []

    prefix_product = 1
    for num in nums:
        prefix_products.append(prefix_product)
        prefix_product *= num

    suffix_product = 1
    for num in reversed(nums):
        suffix_products.append(suffix_product)
        suffix_product *= num

    suffix_products = list(reversed(suffix_products))

    for i in range(n):
        result.append(prefix_products[i] * suffix_products[i])

    return result

# Task 8
def task8(nums):
    max_sum = float('-inf')
    current_sum = 0

    for num in nums:
        current_sum = max(num, current_sum + num)
        max_sum = max(max_sum, current_sum)

    return max_sum

# Task 9
def task9(matrix):
    result = []
    if not matrix:
        return result

    top, bottom = 0, len(matrix) - 1
    left, right = 0, len(matrix[0]) - 1

    while top <= bottom and left <= right:
        for i in range(left, right + 1):
            result.append(matrix[top][i])
        top += 1

        for i in range(top, bottom + 1):
            result.append(matrix[i][right])
        right -= 1

        if top <= bottom:
            for i in range(right, left - 1, -1):
                result.append(matrix[bottom][i])
            bottom -= 1

        if left <= right:
            for i in range(bottom, top - 1, -1):
                result.append(matrix[i][left])
            left += 1

    return result

# Task 10
def task10(points, k):
    distances = [(math.sqrt(x ** 2 + y ** 2), (x, y)) for x, y in points]
    distances.sort(key=lambda d: d[0])
    return [point for _, point in distances[:k]]

