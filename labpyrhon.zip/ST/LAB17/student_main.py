# Task 1
def number_generator(numbers):
    for number in numbers:
        yield number

# Task 2
def even_number_generator(start, end):
    for number in range(start, end + 1):
        if number % 2 == 0:
            yield number

# Task 3
def odd_number_generator(start, end):
    for number in range(start, end + 1):
        if number % 2 != 0:
            yield number

# Task 4
def fibonacci_generator():
    a, b = 0, 1
    while True:
        yield a
        a, b = b, a + b

# Task 5
def is_prime(n):
    if n <= 1:
        return False
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return False
    return True

def prime_number_generator(limit):
    for number in range(2, limit + 1):
        if is_prime(number):
            yield number

# Task 6
class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def pre_order_traversal(root):
    if root:
        yield root.val
        yield from pre_order_traversal(root.left)
        yield from pre_order_traversal(root.right)

# Task 7
def in_order_traversal(root):
    if root:
        yield from in_order_traversal(root.left)
        yield root.val
        yield from in_order_traversal(root.right)

# Task 8
def post_order_traversal(root):
    if root:
        yield from post_order_traversal(root.left)
        yield from post_order_traversal(root.right)
        yield root.val

# Task 9
def dfs_traversal(graph, start):
    visited = set()

    def dfs(node):
        yield node
        visited.add(node)
        for neighbor in graph[node]:
            if neighbor not in visited:
                yield from dfs(neighbor)

    yield from dfs(start)

# Task 10
from collections import deque

def bfs_traversal(graph, start):
    visited = set()
    queue = deque([start])

    while queue:
        node = queue.popleft()
        if node not in visited:
            yield node
            visited.add(node)
            queue.extend(graph[node])

# Task 11
def dict_keys_generator(dictionary):
    for key in dictionary.keys():
        yield key

# Task 12
def dict_values_generator(dictionary):
    for value in dictionary.values():
        yield value

# Task 13
def dict_items_generator(dictionary):
    for item in dictionary.items():
        yield item

# Task 14
def file_lines_generator(file_path):
    with open(file_path, 'r') as file:
        for line in file:
            yield line.strip()

# Task 15
def file_words_generator(file_path):
    with open(file_path, 'r') as file:
        for line in file:
            for word in line.split():
                yield word.strip()

# Task 16
def string_chars_generator(string):
    for char in string:
        yield char

# Task 17
def unique_elements_generator(lst):
    seen = set()
    for item in lst:
        if item not in seen:
            yield item
            seen.add(item)

# Task 18
def reverse_list_generator(lst):
    for item in reversed(lst):
        yield item

# Task 19
def cartesian_product_generator(lst1, lst2):
    for item1 in lst1:
        for item2 in lst2:
            yield (item1, item2)

# Task 20
from itertools import permutations

def permutations_generator(lst):
    yield from permutations(lst)

# Task 21
from itertools import combinations

def combinations_generator(lst):
    for r in range(1, len(lst) + 1):
        yield from combinations(lst, r)

# Task 22
def tuple_list_generator(lst):
    for item in lst:
        yield item

# Task 23
def parallel_lists_generator(*lists):
    min_length = min(len(lst) for lst in lists)
    for i in range(min_length):
        yield tuple(lst[i] for lst in lists)

# Task 24
def flatten_list_generator(lst):
    for item in lst:
        if isinstance(item, list):
            yield from flatten_list_generator(item)
        else:
            yield item

# Task 25
def nested_dict_generator(dictionary):
    for key, value in dictionary.items():
        if isinstance(value, dict):
            yield from nested_dict_generator(value)
        else:
            yield (key, value)

# Task 26
def powers_of_two_generator(n):
    for i in range(n + 1):
        yield 2 ** i

# Task 27
def powers_of_base_generator(base, limit):
    power = 1
    while power <= limit:
        yield power
        power *= base

# Task 28
def squares_generator(start, end):
    for number in range(start, end + 1):
        yield number ** 2

# Task 29
def cubes_generator(start, end):
    for number in range(start, end + 1):
        yield number ** 3

# Task 30
def factorials_generator(n):
    factorial = 1
    for i in range(n + 1):
        yield factorial
        factorial *= (i + 1)

# Task 31
def collatz_sequence_generator(n):
    while n != 1:
        yield n
        if n % 2 == 0:
            n //= 2
        else:
            n = 3 * n + 1
    yield n

# Task 32
def geometric_progression_generator(initial, ratio, limit):
    current = initial
    while current <= limit:
        yield current
        current *= ratio

# Task 33
def arithmetic_progression_generator(initial, difference, limit):
    current = initial
    while current <= limit:
        yield current
        current += difference

# Task 34
def running_sum_generator(lst):
    running_sum = 0
    for number in lst:
        running_sum += number
        yield running_sum

# Task 35
def running_product_generator(lst):
    running_product = 1
    for number in lst:
        running_product *= number
        yield running_product
